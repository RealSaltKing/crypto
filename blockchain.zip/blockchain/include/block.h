#ifndef BLOCK_H
#define BLOCK_H

#include <stdint.h>
#include <time.h>

#define MAX_TRANSACTIONS 10
#define HASH_SIZE 64 // SHA-256 in hex
#define MAX_TRANSACTION_SIZE 256

typedef struct Block {
    uint32_t index;
    time_t timestamp;
    char previous_hash[HASH_SIZE + 1];
    char merkle_root[HASH_SIZE + 1];
    uint32_t nonce;
    char hash[HASH_SIZE + 1];
    char transactions[MAX_TRANSACTIONS][MAX_TRANSACTION_SIZE];
    uint32_t transaction_count;
} Block;

Block *create_block(Block *previous_block);
void compute_block_hash(Block *block);
void mine_block(Block *block, uint32_t difficulty);
void compute_merkle_root(Block *block);

#endif // BLOCK_H
