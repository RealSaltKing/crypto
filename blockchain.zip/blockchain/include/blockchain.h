#ifndef BLOCKCHAIN_H
#define BLOCKCHAIN_H

#include "block.h"

typedef struct Blockchain {
    int dummy; // placeholder
} Blockchain;

Blockchain *create_blockchain();
void add_block(Blockchain *bc);
void save_block(Block *block);
Block *load_last_block();

#endif // BLOCKCHAIN_H
