#include "blockchain.h"
#include <stdio.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <sys/types.h>

int main() {
    struct stat st = {0};

    if (stat("artifacts", &st) == -1) {
        mkdir("artifacts", 0700);
    }

    Blockchain *bc = create_blockchain();
    add_block(bc);

    printf("Successfully mined and saved a new block!\n");

    free(bc);
    return 0;
}
