#include "blockchain.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Blockchain *create_blockchain() {
    Blockchain *bc = malloc(sizeof(Blockchain));
    return bc;
}

void add_block(Blockchain *bc) {
    Block *last_block = load_last_block();
    Block *new_block = create_block(last_block);

    save_block(new_block);

    if (last_block)
        free(last_block);
    free(new_block);
}

void save_block(Block *block) {
    char filename[256];
    snprintf(filename, sizeof(filename), "artifacts/block_%u.dat", block->index);

    FILE *fp = fopen(filename, "wb");
    if (!fp) {
        perror("fopen");
        exit(1);
    }

    fwrite(block, sizeof(Block), 1, fp);
    fclose(fp);
}

Block *load_last_block() {
    uint32_t idx = 0;
    Block *last = NULL;
    char filename[256];

    while (1) {
        snprintf(filename, sizeof(filename), "artifacts/block_%u.dat", idx);

        FILE *fp = fopen(filename, "rb");
        if (!fp) {
            break;
        }

        if (last != NULL) {
            free(last);
        }

        last = (Block *)malloc(sizeof(Block));
        if (fread(last, sizeof(Block), 1, fp) != 1) {
            free(last);
            last = NULL;
        }
        fclose(fp);

        idx++;
    }

    return last; // May be NULL if no blocks exist yet
}