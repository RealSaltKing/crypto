#include "block.h"
#include "heap_t.h"
#include "shainc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void compute_block_hash(Block *block) {
    char temp[4096] = {0};

    snprintf(temp, sizeof(temp),
             "%u%ld%s%s%u",
             block->index,
             block->timestamp,
             block->previous_hash,
             block->merkle_root,
             block->nonce);

    sha256(temp, block->hash);
}

void mine_block(Block *block, uint32_t difficulty) {
    char prefix[HASH_SIZE + 1] = {0};
    memset(prefix, '0', difficulty);
    prefix[difficulty] = '\0';

    do {
        block->nonce++;
        compute_block_hash(block);
    } while (strncmp(block->hash, prefix, difficulty) != 0);
}

void compute_merkle_root(Block *block) {
    if (!block) {
        printf("ERROR: compute_merkle_root received NULL block!\n");
        exit(1);
    }

    if (block->transaction_count == 0) {
        printf("No transactions. Setting Merkle root to 0.\n");
        strcpy(block->merkle_root, "0");
        return;
    }


    heap_t heap = heap_new(sizeof(char) * (HASH_SIZE + 1), NULL);

    for (uint32_t i = 0; i < block->transaction_count; i++) {
        if (strlen(block->transactions[i]) == 0) {
            printf("Warning: Empty transaction at index %u\n", i);
            continue;
        }
        char hashed_txn[HASH_SIZE + 1] = {0};
        sha256(block->transactions[i], hashed_txn);
        heap_insert(heap, strdup(hashed_txn));
    }

    if (heap.size == 0) {
        strcpy(block->merkle_root, "0");
        heap_free(heap);
        return;
    }

    while (heap.size > 1) {
        char *left = (char *)heap_maxpop(heap);
        char *right = (char *)heap_maxpop(heap);

        if (left == NULL || right == NULL) {
            printf("ERROR: NULL left or right in Merkle building\n");
            exit(1);
        }

        char combined[2 * HASH_SIZE + 1] = {0};
        snprintf(combined, sizeof(combined), "%s%s", left, right);

        char new_hash[HASH_SIZE + 1] = {0};
        sha256(combined, new_hash);

        heap_insert(heap, strdup(new_hash));

        free(left);
        free(right);
    }

    char *root = (char *)heap_maxpop(heap);
    if (root == NULL) {
        printf("ERROR: Merkle root extraction failed!\n");
        exit(1);
    }
    strncpy(block->merkle_root, root, HASH_SIZE);
    block->merkle_root[HASH_SIZE] = '\0';
    free(root);

    heap_free(heap);
}

Block *create_block(Block *previous_block) {
    printf("-> Creating new block\n");

    Block *block = (Block *)malloc(sizeof(Block));
    if (!block) {
        printf("ERROR: Failed to allocate memory for block!\n");
        exit(1);
    }
    memset(block, 0, sizeof(Block));
    printf("Allocated memory for block.\n");

    block->index = (previous_block == NULL) ? 0 : previous_block->index + 1;
    block->timestamp = time(NULL);
    printf("Block index: %u\n", block->index);

    block->transaction_count = 3;
    strcpy(block->transactions[0], "UserA -> UserB 5 coins");
    strcpy(block->transactions[1], "UserC -> UserD 2 coins");
    strcpy(block->transactions[2], "UserE -> UserF 1 coins");
    printf("Assigned dummy transactions.\n");

    if (previous_block != NULL) {
        strncpy(block->previous_hash, previous_block->hash, HASH_SIZE);
    } else {
        strcpy(block->previous_hash, "0");
    }

    printf("Previous hash assigned.\n");

    block->nonce = 0;

    compute_merkle_root(block);

    mine_block(block, 1);

    return block;
}
