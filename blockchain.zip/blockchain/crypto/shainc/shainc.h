#ifndef SHAINC_H
#define SHAINC_H

#define SHA256_BLOCK_SIZE 32            // SHA256 outputs 32 bytes = 256 bits

typedef struct {
    unsigned char data[64];
    unsigned int datalen;
    unsigned int bitlen[2];
    unsigned int state[8];
} SHA256_CTX;

void sha256_init(SHA256_CTX *ctx);
void sha256_update(SHA256_CTX *ctx, const unsigned char data[], size_t len);
void sha256_final(SHA256_CTX *ctx, unsigned char hash[]);

// Utility function you will use in blockchain
void sha256(const char *string, char outputBuffer[65]);

#endif // SHAINC_H
