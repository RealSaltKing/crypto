#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ROTOR_COUNT 7
#define ALPHABET_SIZE 26
#define ALPHABET "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

// Rotor definitions
const char *rotors[ROTOR_COUNT] = {
    "BDFHJLCPRTXVZNYEIWGAKMUSQO", // Fast
    "AJDKSIRUXBLHWTMCQGZNPYFVOE", // Medium
    "EKMFLGDQVZNTOWYHXUSPAIBRCJ", // Slow
    "IXUHFEZDAOMTKQJWNSRLCYPBVG", // Reflector
    "UWYGADFPVZBECKMTHXSLRINQOJ", // Slow (inverse)
    "AJPCZWRLFBDKOTYUQGENHXMIVS", // Medium (inverse)
    "TAGBPCSDQEUFVNZHYIXJWLRKOM"  // Fast (inverse)
};

// Function to find the index of a character in the alphabet
int char_to_index(char c) {
    return c - 'A';
}

// Function to shift a character within the alphabet
char shift_char(char c, int shift) {
    return ALPHABET[(char_to_index(c) + shift + ALPHABET_SIZE) % ALPHABET_SIZE];
}

// Function to apply a rotor to a character
char apply_rotor(char c, const char *rotor, int shift) {
    c = shift_char(c, shift); // Apply forward shift
    c = rotor[char_to_index(c)];
    c = shift_char(c, -shift); // Apply reverse shift
    return c;
}

// Function to process a single letter through the Enigma machine
char process_letter(char c, int l) {
    int shifts[ROTOR_COUNT] = {
        l % ALPHABET_SIZE,                   // Fast rotor
        (l / ALPHABET_SIZE) % ALPHABET_SIZE, // Medium rotor
        (l / (ALPHABET_SIZE * ALPHABET_SIZE)) % ALPHABET_SIZE, // Slow rotor
        0,                                   // Reflector (no shift)
        (l / (ALPHABET_SIZE * ALPHABET_SIZE)) % ALPHABET_SIZE, // Slow (inverse)
        (l / ALPHABET_SIZE) % ALPHABET_SIZE, // Medium (inverse)
        l % ALPHABET_SIZE                    // Fast (inverse)
    };

    for (int i = 0; i < ROTOR_COUNT; i++) {
        c = apply_rotor(c, rotors[i], shifts[i]);
    }
    return c;
}

// Function to encrypt a message
void encrypt_message(const char *input, char *output) {
    for (int i = 0; input[i] != '\0'; i++) {
        output[i] = process_letter(input[i], i + 1);
    }
    output[strlen(input)] = '\0'; // Null-terminate the string
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <MESSAGE>\n", argv[0]);
        return 1;
    }

    const char *message = argv[1];
    size_t len = strlen(message);
    char *encrypted = malloc(len + 1);

    if (!encrypted) {
        fprintf(stderr, "Memory allocation failed!\n");
        return 1;
    }

    encrypt_message(message, encrypted);

    printf("Encrypted Message: %s\n", encrypted);

    free(encrypted);
    return 0;
}